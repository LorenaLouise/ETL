$fileDir = Split-Path -Parent $MyInvocation.MyCommand.Path
cd $fileDir
java '-Xms1024M' '-Xmx4096M' '-Dfile.encoding=UTF-8' -cp '.;../lib/routines.jar;../lib/dom4j-1.6.1.jar;../lib/jtds-1.3.1-patch.jar;../lib/log4j-1.2.16.jar;../lib/talend_DB_mssqlUtil-1.2-20171017.jar;dim_data_0_1.jar;' tcc.dim_data_0_1.dim_data  %* 